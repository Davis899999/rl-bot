# sq-starter
The starting point for bots built through Skillquest courses. Based on GoslingUtils.

## Course
Find out more about our RLBot course on [our website](https://skillquest.io) or through the [Discord community](https://discord.gg/hqkKfMpPvX).
